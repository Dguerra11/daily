# ⚡ JEJUM.GG

App de jejum intermitente para grupos de amigos.

---

## 🚀 Como publicar (passo a passo)

### 1. Criar projeto no Firebase

1. Vai a **https://console.firebase.google.com**
2. Clica em **"Add project"** → dá o nome `jejum-gg`
3. Desativa o Google Analytics (não precisas) → **Create project**
4. No menu lateral: **Build → Realtime Database**
5. Clica **"Create database"**
6. Escolhe **"Start in test mode"** → **Next** → **Enable**
7. Copia o URL da database (ex: `https://jejum-gg-default-rtdb.firebaseio.com`)

### 2. Obter as credenciais do Firebase

1. Clica no ⚙️ (engrenagem) → **Project settings**
2. Em **"Your apps"**, clica em **"</>"** (Web)
3. Dá um nome (ex: `jejum-web`) → **Register app**
4. Copia os valores do `firebaseConfig`

### 3. Colocar o código no GitHub

1. Vai a **https://github.com** → **New repository**
2. Nome: `jejum-gg` → **Create repository**
3. Faz upload desta pasta toda (arrasta os ficheiros para o GitHub)

### 4. Publicar no Vercel

1. Vai a **https://vercel.com** → **Sign up with GitHub**
2. Clica **"Add New Project"** → seleciona o repositório `jejum-gg`
3. Antes de fazer deploy, vai a **"Environment Variables"** e adiciona:

```
REACT_APP_FIREBASE_API_KEY          = (o teu apiKey)
REACT_APP_FIREBASE_AUTH_DOMAIN      = (o teu authDomain)
REACT_APP_FIREBASE_DATABASE_URL     = (o URL da Realtime Database)
REACT_APP_FIREBASE_PROJECT_ID       = (o teu projectId)
REACT_APP_FIREBASE_STORAGE_BUCKET   = (o teu storageBucket)
REACT_APP_FIREBASE_MESSAGING_SENDER_ID = (o teu messagingSenderId)
REACT_APP_FIREBASE_APP_ID           = (o teu appId)
```

4. Clica **Deploy** 🚀

### 5. Partilha com os amigos!

O Vercel dá-te um link tipo `jejum-gg.vercel.app`.  
Partilha no grupo e cada um entra com o seu nome! 🎉

---

## 📁 Estrutura do projeto

```
jejum-app/
├── public/
│   └── index.html
├── src/
│   ├── App.js        ← app principal
│   ├── firebase.js   ← configuração Firebase
│   └── index.js      ← entrada React
├── package.json
└── README.md
```
